export const UserData = [
  {
    name: "Jan",
    "Active User": 4000,
  },
  {
    name: "Feb",
    "Active User": 3000,
  },
  {
    name: "Mar",
    "Active User": 2000,
  },
  {
    name: "April",
    "Active User": 1000,
  },
  {
    name: "May",
    "Active User": 4000,
  },
  {
    name: "Jun",
    "Active User": 5000,
  },
  {
    name: "July",
    "Active User": 9000,
  },
  {
    name: "Aug",
    "Active User": 8000,
  },
  {
    name: "Sept",
    "Active User": 10000,
  },
  {
    name: "Oct",
    "Active User": 11000,
  },
  {
    name: "Nov",
    "Active User": 7000,
  },
  {
    name: "Dec",
    "Active User": 4000,
  },
]
export const UserRows = [
  { id: 1, username: "Snow", email: "snow@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 2, username: "Lannister", email: "Lannister@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 3, username: "Lannister", email: "Lannister@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 4, username: "Stark", email: "Stark@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 5, username: "Targaryen", email: "LanTargaryennister@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 6, username: "Melisandre", email: "Melisandre@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 7, username: "Clifford", email: "Clifford@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 8, username: "Frances", email: "Frances@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
  { id: 9, username: "Roxie", email: "Roxie@gmail.com", status: "active", transaction: "$120.00", avater: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?cs=srgb&dl=pexels-hannah-nelson-1065084.jpg&fm=jpg" },
]
